"use strict";

const SWIFT_POR_MARCA = {
  'VISA': 'BQTOECEC',
  'MASTERCARD': 'BQTOECMC',
  'AMEX': 'BQTOECAX'
};

const MARCAS_ACEPTADAS = ['VISA', 'MASTERCARD', 'AMEX'];

module.exports.validarMarca = async (event) => {
  try {
    const request = JSON.parse(event.body || '{}');
    console.log('Iniciando validación de marca para tarjeta:', request.numeroTarjeta);

    // Validaciones
    const validationResult = await validateCard(request);
    if (!validationResult.isValid) {
      return formatResponse(400, {
        tarjetaValida: false,
        mensaje: validationResult.message
      });
    }

    // Respuesta exitosa
    return formatResponse(200, {
      tarjetaValida: true,
      marca: validationResult.marca,
      swiftBanco: SWIFT_POR_MARCA[validationResult.marca],
      mensaje: "Tarjeta válida"
    });

  } catch (error) {
    console.error('Error en validación:', error);
    return formatResponse(500, {
      tarjetaValida: false,
      mensaje: "Error interno en la validación",
      error: error.message
    });
  }
};

async function validateCard(request) {
  // 1. Validar que existan todos los campos requeridos
  if (!request.numeroTarjeta || !request.marca || !request.cvv || !request.fechaCaducidad) {
    return { isValid: false, message: "Todos los campos son requeridos" };
  }

  // 2. Identificar marca por BIN
  const marcaDetectada = identificarMarcaPorBIN(request.numeroTarjeta);
  if (!MARCAS_ACEPTADAS.includes(marcaDetectada)) {
    return { isValid: false, message: `Marca de tarjeta no soportada: ${marcaDetectada}` };
  }

  // 3. Validar que la marca proporcionada coincida con la detectada
  if (marcaDetectada !== request.marca) {
    return { isValid: false, message: "Marca declarada no coincide con BIN de tarjeta" };
  }

  // 4. Validar algoritmo de Luhn
  if (!validarAlgoritmoLuhn(request.numeroTarjeta)) {
    return { isValid: false, message: "Número de tarjeta inválido" };
  }

  // 5. Validar CVV
  if (!validarCVV(request.cvv, marcaDetectada)) {
    return { isValid: false, message: "CVV inválido" };
  }

  // 6. Validar fecha de caducidad
  function validarFechaCaducidad(fechaCaducidad) {
    try {
      // Convertimos la fecha de "YYYY-MM-DD" a objeto Date
      const fechaExpiracion = new Date(fechaCaducidad);
      const fechaActual = new Date();
  
      // Validamos que la fecha no haya expirado
      return fechaExpiracion > fechaActual;
    } catch (error) {
      return false;
    }
  }

  return { isValid: true, marca: marcaDetectada };
}

function identificarMarcaPorBIN(numeroTarjeta) {
  if (!numeroTarjeta || numeroTarjeta.length < 2) return "DESCONOCIDA";

  const bin = numeroTarjeta.substring(0, 2);
  if (["34", "37"].includes(bin)) return "AMEX";
  if (["51", "52", "53", "54", "55"].includes(bin)) return "MASTERCARD";
  if (bin >= "40" && bin <= "49") return "VISA";
  return "DESCONOCIDA";
}

function validarAlgoritmoLuhn(numeroTarjeta) {
  if (!numeroTarjeta || numeroTarjeta.length !== 16) return false;

  let sum = 0;
  let alternate = false;
  
  for (let i = numeroTarjeta.length - 1; i >= 0; i--) {
    let n = parseInt(numeroTarjeta.charAt(i), 10);
    if (alternate) {
      n *= 2;
      if (n > 9) n = (n % 10) + 1;
    }
    sum += n;
    alternate = !alternate;
  }
  
  return (sum % 10 === 0);
}

function validarCVV(cvv, marca) {
  if (!cvv) return false;
  const longitudEsperada = marca === "AMEX" ? 4 : 3;
  return new RegExp(`^\\d{${longitudEsperada}}$`).test(cvv);
}

function validarFechaCaducidad(fechaCaducidad) {
  try {
    const partesFecha = fechaCaducidad.includes("/") ? fechaCaducidad.split('/') : fechaCaducidad.split('-');
    if (partesFecha.length < 2) return false;

    const mes = parseInt(partesFecha[0], 10);
    const anio = parseInt(partesFecha[1], 10);
    
    if (isNaN(mes) || isNaN(anio) || mes < 1 || mes > 12) return false;
    
    const fechaActual = new Date();
    const fechaTarjeta = new Date(anio < 100 ? 2000 + anio : anio, mes - 1);

    return fechaTarjeta > fechaActual;
  } catch (e) {
    return false;
  }
}

function formatResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': true,
    },
    body: JSON.stringify(body)
  };
}
